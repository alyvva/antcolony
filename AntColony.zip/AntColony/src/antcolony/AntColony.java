/*
5704522
COP2210 - Fall 2017
Assignment #2
10/6/17
I hereby swear and affirm that this work is solely my own, and not the work 
or the derivative of the work of someone else.
 */
package antcolony;


import javax.swing.*;

/**
 *
 * @author alyvv
 */
public class AntColony {
    
    /**
     *
     * @param args
     */
    
public static void main(String[] args) {
        

AntColonyTester startingColony = new AntColonyTester(); //new object

    String qName = JOptionPane.showInputDialog(null, "Enter your queen's name."); 
    startingColony.setqueenName(qName);
    
    String ColonyName = JOptionPane.showInputDialog(null, "Enter your colony's name.");
    startingColony.setantColonyName(ColonyName);
    
    String careTaker = JOptionPane.showInputDialog(null, "Enter the caretaker's name.");
    startingColony.setcareTaker(careTaker);
    
    String initialpop = JOptionPane.showInputDialog(null, "Enter starting size of colony.");
    int size = Integer.parseInt(initialpop);
    startingColony.setstartingSize(size);
    
    String days = JOptionPane.showInputDialog(null, "Enter how many day(s) ants were fed.");
    startingColony.setdaysFed(days);
    
    String queenBirths = JOptionPane.showInputDialog(null, "Enter how many Queens you want bred.");
    startingColony.setnumberQueensBred(queenBirths);
    
    String Expansion = JOptionPane.showInputDialog("Do you want to expand your colony?"
             + "yes or no?");
    startingColony.setexpansion(Expansion); 
     

    JOptionPane.showMessageDialog(null, "Your queen's name is " + 
            startingColony.getqueenName() + ".");
    JOptionPane.showMessageDialog(null,"Your colony's name is " + 
            startingColony.getantColonyName() + ".");
    JOptionPane.showMessageDialog(null,"Your name is " + 
            startingColony.getcareTaker() + "."); 
    JOptionPane.showMessageDialog(null,"Your starting size colony is " +
            startingColony.getSize() + ".");
    JOptionPane.showMessageDialog(null,"You want your colony to be fed for " +
            startingColony.getdaysFed() + " days.");
    JOptionPane.showMessageDialog(null,"You want this many queens bred: " +
            startingColony.getnumberQueensBred() + "."); 
    JOptionPane.showMessageDialog(null,"You answered " +
            startingColony.getexpansion() + " to expand your colony.");
   
   
    
    startingColony.lifespanMethod();
    startingColony.expandMethod();
   
  
   JOptionPane.showMessageDialog(null, "Your final population size is " +
            startingColony.getSize() + ".");
   
           
    
            
   




       
    }
    
}
