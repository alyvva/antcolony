/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package antcolony;

import javax.swing.JOptionPane;
import java.util.Random;

/**
 *
 * @author alyvv
 */
public class AntColonyTester {
 //variables needed
String queenName;
String antColonyName;
String careTaker;
int startingSize;
String daysFed;
String numberQueensBred;
String lifespanMethod;
String expansion;

String getqueenName(){
    return queenName;
}
String getantColonyName(){
    return antColonyName;
}
String getcareTaker(){
    return careTaker;
}
int getSize(){
    return startingSize;
}
String getdaysFed(){
    return daysFed;
}
String getnumberQueensBred(){
    return numberQueensBred;
}
String getexpansion(){
    return expansion;
}

void setqueenName(String qName){
     queenName = qName;
}
void setantColonyName(String colonyName){
    antColonyName = colonyName;
}
void setcareTaker(String CareTaker){
     careTaker = CareTaker;
}
void setstartingSize(int initialpop){
     startingSize = initialpop;
}
void setdaysFed(String days){
     daysFed = days;
}
void setnumberQueensBred(String queenBirths){
     numberQueensBred = queenBirths;
}
void setexpansion(String Expansion){
     expansion = Expansion;
}


 public void lifespanMethod(){
    int days = Integer.parseInt(daysFed);
    int bred = Integer.parseInt(numberQueensBred);
    //int size = Integer.parseInt(startingSize);

if(days > 10){
    int lifespan = bred - 1;
    //If user gives colony food for more than 10 days, queen will die
    startingSize = startingSize / 2;
    //50% of the colony will die as well  
    
JOptionPane.showMessageDialog(null,"After determining your new lifespan, you now "
   + "have " + lifespan + " queens and a new population of " + startingSize + ".");
}
if(days < 10){
    int queen = bred;
    startingSize = startingSize * 3;
    //As long as user doesn't feed colony for more than 10 days, colony 
    //will triple in size!   
    
JOptionPane.showMessageDialog(null,"After determining your new lifespan, you now "
   + "have " + queen + " queens and a new population of " + startingSize + ".");
}
}
 
Random r = new Random();
int percentage = 1 + r.nextInt(10);

public void expandMethod() {
    String y = "yes";
    String n = "no";
    
if(expansion.equals(y)){
    if(percentage <= 5) {
        
        JOptionPane.showMessageDialog(null, "No new queen will be born.");
    }
    else if (percentage > 5){
        JOptionPane.showMessageDialog(null, "A new queen named " + queenName + " 2.0 "
                + "is born.");
    }
  
    if(expansion.equals(n)){
    if(percentage == 1) {
        
        JOptionPane.showMessageDialog(null, "A new queen named " + queenName + " 2.0 "
                + "is born.");
    }
    else if (percentage > 1){
        JOptionPane.showMessageDialog(null, "No new queen will be born.");
    }
}}}


}


 